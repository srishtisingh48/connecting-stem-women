var display = document.getElementById("answers");
var buttonClicked = document.getElementById("buttonClicked");


if (buttonClicked) {
  buttonClicked.addEventListener("click", makeScript);
}

function makeScript() {
  var name = document.getElementById("name").value;
  var location = document.getElementById("location").value;
  var reasoning = document.getElementById("reasoning").value;

  display.innerHTML = "Hello, my name is " + name + " and I live in " + location + ". I am calling to ask you to support the Paycheck Fairness Act so women working the same hours as men are paid equally. As a person passionate in STEM-related fields, I want to live in an environment where all people are treated fairly. " + reasoning + " Please support the Paycheck Fairness Act which ensures equal pay reguardless of gender.";
}

var s = document.getElementById("story");
s.style.display = "none";
function myStory(){
  if (s.style.display === "none") {
    s.style.display = "block";
  } else {
    s.style.display = "none";
  }
}

var s2 = document.getElementById("story2");
s2.style.display = "none";
function myStory2(){
  if (s2.style.display === "none") {
    s2.style.display = "block";
  } else {
    s2.style.display = "none";
  }
}

var s3 = document.getElementById("story3");
s3.style.display = "none";
function myStory3(){
  if (s3.style.display === "none") {
    s3.style.display = "block";
  } else {
    s3.style.display = "none";
  }
}

var s4 = document.getElementById("story4");
s4.style.display = "none";
function myStory4(){
  if (s4.style.display === "none") {
    s4.style.display = "block";
  } else {
    s4.style.display = "none";
  }
}

var s5 = document.getElementById("story5");
s5.style.display = "none";
function myStory5(){
  if (s5.style.display === "none") {
    s5.style.display = "block";
  } else {
    s5.style.display = "none";
  }
}

var s6 = document.getElementById("story6");
s6.style.display = "none";
function myStory6(){
  if (s6.style.display === "none") {
    s6.style.display = "block";
  } else {
    s6.style.display = "none";
  }
}

var s7 = document.getElementById("story7");
s7.style.display = "none";
function myStory7(){
  if (s7.style.display === "none") {
    s7.style.display = "block";
  } else {
    s7.style.display = "none";
  }
}
var s8 = document.getElementById("story8");
s8.style.display = "none";
function myStory8(){
  if (s8.style.display === "none") {
    s8.style.display = "block";
  } else {
    s8.style.display = "none";
  }
}
var s9 = document.getElementById("story9");
s9.style.display = "none";
function myStory9(){
  if (s9.style.display === "none") {
    s9.style.display = "block";
  } else {
    s9.style.display = "none";
  }
}
var s10 = document.getElementById("story10");
s10.style.display = "none";
function myStory10(){
  if (s10.style.display === "none") {
    s10.style.display = "block";
  } else {
    s10.style.display = "none";
  }
}
var s11 = document.getElementById("story11");
s11.style.display = "none";
function myStory11(){
  if (s11.style.display === "none") {
    s11.style.display = "block";
  } else {
    s11.style.display = "none";
  }
}